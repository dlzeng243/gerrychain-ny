2022 New York Congressional Districts Plan - Invalidated on April 27, 2022 by the New York State Court of Appeals

##Redistricting Data Hub (RDH) Retrieval Date
02/08/2022

##Sources
This dataset was retrieved from the New York State Legislative Task Force on Demographic Research and Reapportionment: https://latfor.state.ny.us/maps/

##Processing
The RDH did not modify any of the data.

##Additional Notes
Enclosed in this zip file the shapefile file for New York's Congressional Districts ("Congress22.shp") and supporting files, a population report ("2022_congress_population_report.pdf"), a statewide map ("con-nys.pdf"), a New York City map ("con-nyc.pdf"), a Long Island map ("con-li.pdf"), and a block assignment file ("Congress2022_BlockEquivalency.dbf").

To keep track of a state's adopted maps, go to All About Redistricting https://redistricting.lls.edu/
For any additional questions, please email info@redistrictingdatahub.org